#!/bin/bash

(nohup perl /opt/homebrew/cellar/vanta_darwin_x64_v2.0.0/2.0.0/bin/vanta_compliance.pl > /dev/null 2>&1 &)
