#!/usr/bin/perl
use strict;
use warnings;

# Define file name
my $filename = "Hello";

# Open file for writing
open(my $fh, '>', $filename) or die "Could not open file '$filename' $!";

# Write content
print $fh "Hello Mundo\n";

# Close file
close($fh);

print "File '$filename' created successfully!\n";
